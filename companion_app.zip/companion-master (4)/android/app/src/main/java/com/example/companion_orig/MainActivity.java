package com.example.companion_orig;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
 
}
