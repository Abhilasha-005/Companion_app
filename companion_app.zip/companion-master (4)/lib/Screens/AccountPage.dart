import 'package:flutter/material.dart';

class AccountPage extends StatefulWidget{
  AccountPage();

@override
AccountPageState createState()=> AccountPageState();
}

class AccountPageState extends State<AccountPage>{

  @override
  Widget build(BuildContext context){
    return Container();
  }
}