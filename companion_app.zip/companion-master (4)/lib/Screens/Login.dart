import 'package:flutter/material.dart';
import 'package:companion/main.dart';
import 'package:companion/ClientModel.dart';
import 'package:companion/Database.dart';

//import 'dart:io';
class Login extends StatefulWidget {
  @override
  LoginState createState() => LoginState();
}

class LoginState extends State<Login> {
  static Client pehla = Client(firstName: "CHOOSE AN EXISTING USER");
  List<Client> clients = [
    pehla
  ];
  String name;

  @override
  void initState() {
    getClients();
    super.initState();
  }

  void getClients() async {
    clients = await DBProvider.db.getAllClients();
    setState(() {});
  }

  final controller = TextEditingController();
  int id;

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Column(
        children: <Widget>[
          Image.asset("assets/drawer.jpg"),
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              onEditingComplete: () {
                name = controller.text;
              },
              controller: controller,
              decoration: InputDecoration(hintText: "Enter Name"),
            ),
          ),
          // ignore: deprecated_member_use
          RaisedButton(
            child: Text('Proceed'),
            onPressed: () async {
              Client newClient = Client(firstName: controller.text);
              id = await DBProvider.db.newClient(newClient);
              // while (newClient.id != null) {
              //   sleep(Duration(seconds: 2));
              // }
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MyHomePage(title: 'Your Companion', id: id),
                ),
              );
            },
          ),
          Flexible(
            child: ListView.builder(
              itemCount: clients.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Text(clients[index].firstName),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MyHomePage(title: 'Your Companion', id: id),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
